import 'package:ui_library/ui_library.dart';
 String curr="Rs";

class Zconstant{

  static double margin=20.px;

  static double margin16=16.px;
  static double margin18=18.px;

}