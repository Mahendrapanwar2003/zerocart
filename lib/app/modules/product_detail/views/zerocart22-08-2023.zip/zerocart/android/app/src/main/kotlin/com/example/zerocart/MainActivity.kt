package com.example.zerocart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
